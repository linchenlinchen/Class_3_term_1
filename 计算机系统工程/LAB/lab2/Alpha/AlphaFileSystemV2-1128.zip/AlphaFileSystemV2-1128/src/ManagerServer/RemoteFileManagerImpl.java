package ManagerServer;

import itf.File;
import itf.FileManager;
import itf.Id;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/*ClassName RemoteFileManager
 *Description
 *Author 2019/11/27
 *Date 2019/11/27 16:08
 *Version 1.0
 */
public class RemoteFileManagerImpl extends UnicastRemoteObject implements FMAdapter, Serializable {
    /*attribute*/
    private FileManager fileManager;
    /*constructor*/
    public RemoteFileManagerImpl(FileManager fileManager) throws RemoteException {
        super();
        this.fileManager = fileManager;
    }
    /*method*/
    @Override
    public FileManager getFileManager(){return fileManager;}
    @Override
    public File getFile(Id id){
        return getFileManager().getFile(id);
    }
}
