package Client;

import ManagerServer.BMAdapter;
import ManagerServer.FMAdapter;
import exception.ErrorCode;
import id.BlockId;
import id.FileId;
import itf.Block;
import itf.File;
import itf.Id;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;
import java.util.regex.Pattern;

import static exception.ErrorCode.BUILD_FILE_OF_FILEMETA_FAILED;
import static exception.ErrorCode.getErrorText;

/*ClassName Client
 *Description This is Client
 *Author 2019/11/23
 *Date 2019/11/23 14:09
 *Version 1.0
 */
public class Client {

    public static String getCommand(String pattern, Scanner scanner){
        if("CAT".equals(pattern)|| "HEX".equals(pattern) || "WRITE".equals(pattern) || "COPY".equals(pattern)) {
            return pattern;
        }else {
            System.out.println("输入错误，请重试:");
            String newPattern = scanner.nextLine();
            return getCommand(newPattern,scanner);
        }
    }

    public static int getInt(String pattern, Scanner scanner){
        if(isInteger(pattern)){
            return Integer.parseInt(pattern);
        }else {
            System.out.println("请输入数字，请重试：");
            String newPattern  = scanner.nextLine();
            return getInt(pattern,scanner);
        }
    }

    public static void main(String[] args)throws Exception{
        try {
            Registry registry = LocateRegistry.getRegistry("127.0.0.1",8888, (host, port) -> {
                Socket socket = new Socket();
                socket.connect(new InetSocketAddress(host, port), 2000);/*超时*/
                return socket;
            });
            while (true){
                Scanner input = new Scanner(System.in);
                String pattern = input.nextLine();
                pattern = getCommand(pattern,input);
                switch (pattern){
                    case "HEX":System.out.println("请输入BM名：");
                        String bmName = input.nextLine();
                        System.out.println("请输入块号：");
                        String blockIndex_str = input.nextLine();
                        int blockIndex = getInt(blockIndex_str,input);
                        System.out.println("请输入字节长度：");
                        String length_str = input.nextLine();
                        int length = getInt(length_str,input);
                        alpha_hex(registry,bmName,blockIndex,length);
                        break;
                    case "CAT":System.out.println("请输入FM名：");
                        String fmName = input.nextLine();
                        System.out.println("请输入文件名：");
                        String fileName = input.nextLine();
                        System.out.println("请输入字节长度：");
                        String length_str1 = input.nextLine();
                        int length1 = getInt(length_str1,input);
                        alpha_cat_file(registry,fmName,fileName,length1);
                        break;
                    case "WRITE":System.out.println("请输入FM名：");
                        String fmName1 = input.nextLine();
                        System.out.println("请输入文件名：");
                        String fileName1 = input.nextLine();
                        System.out.println("请移动游标：");
                        String pos_str = input.nextLine();
                        int pos = getInt(pos_str,input);
                        System.out.println("请输入数据：");
                        String data_str = input.nextLine();
                        byte[] data = data_str.getBytes();
                        alpha_write(registry,fmName1,fileName1,pos,data);
                        break;
                    case "COPY":System.out.println("请输入旧FM名：");
                        String old_fmName = input.nextLine();
                        System.out.println("请输入旧的文件名：");
                        String old_fileName = input.nextLine();
                        System.out.println("请输入新FM名：");
                        String new_fmName = input.nextLine();
                        System.out.println("请输入新的文件名：");
                        String new_fileName = input.nextLine();
                        alpha_copy(registry,old_fmName,old_fileName,new_fmName,new_fileName);
                        break;
                    default:break;
                }
            }
        }catch (NotBoundException e){
            System.out.println("尊敬的客户，你想要获取的内容尚未启用！请稍后再试\nDear customers, the content you want to get has not been enabled yet! Please try again later");
        }catch (RemoteException e){
            System.out.println("尊敬的客户，远程连接出现错误，请稍后再试试吧\nDear customer, remote connection error, please try again later");
        }

    }

    public static void alpha_cat_file(Registry registry,String fmName,String fileName,int length){
        byte[] result = read(registry,fmName,fileName,length);
        System.out.println(result.toString());
    }

    public static void alpha_hex(Registry registry,String BMName,int blockIndex,int length)throws Exception{
        BMAdapter bmAdapter = (BMAdapter) registry.lookup("rmi://localhost:8888/"+BMName);
        Id id = new BlockId(blockIndex);
        Block block = bmAdapter.getBlock(id);
        byte[] data = block.read();
        length = length>data.length?data.length:length;
        for (int i = 0; i < length; i++) {
            System.out.print(Integer.toHexString(data[i]));
        }
        System.out.println();
    }

    public static void alpha_write(Registry registry,String fmName,String fileName,int pos,byte[] data)throws Exception{
        FMAdapter fmAdapter = (FMAdapter)registry.lookup("rmi://localhost:8888/"+fmName);
        Id id = new FileId(fileName);
        File file = fmAdapter.getFile(id);
        file.move(pos,File.MOVE_HEAD);
        file.write(data);
    }

    public static void alpha_copy(Registry registry,String fmName,String fileName,String newFMName,String newFName)throws Exception {
        try {
            FMAdapter fmAdapter = (FMAdapter) registry.lookup("rmi://localhost:8888/" + fmName);
            Id id = new FileId(fileName);
            File file = fmAdapter.getFile(id);
            byte[] data = file.read((int) (file.size()));
            File file1 = newFile(registry,newFMName,newFName);
            file1.write(data);
        } catch (IOException e) {
            System.out.println(ErrorCode.getErrorText(10));
        }
    }

    public static File newFile(Registry registry,String fmName,String fileName) throws Exception{
        File file = null;
        try {
            FMAdapter fmAdapter = (FMAdapter) registry.lookup("rmi://localhost:8888/"+fmName);
            file = fmAdapter.getFileManager().newFile(new FileId(fileName));
        }catch (NotBoundException e){
            System.out.println("尊敬的客户，你想要获取的内容尚未启用！请稍后再试\nDear customers, the content you want to get has not been enabled yet! Please try again later");
        }catch (RemoteException e){
            System.out.println("尊敬的客户，远程连接出现错误，请稍后再试试吧\nDear customer, remote connection error, please try again later");
        }
        /*如果仍然为null，抛出异常*/
        if(file==null){
            System.out.println(getErrorText(BUILD_FILE_OF_FILEMETA_FAILED));
            throw new Exception();
        }
        return file;/*由于newFile方法并不会得到一个null，故只要不出异常均非null*/
    }

    public void write(Registry registry,String fmName,String fileName,byte[] data)throws Exception{
        File file = newFile(registry,fmName,fileName);
        file.write(data);
    }

    public static byte[] read(Registry registry,String fmName,String fileName,int length){
        File file = null;
        try {
            FMAdapter fmAdapter = (FMAdapter) registry.lookup("rmi://localhost:8888/"+fmName);
            file = fmAdapter.getFileManager().getFile(new FileId(fileName));
        }catch (NotBoundException e){
            System.out.println("尊敬的客户，你想要获取的内容尚未启用！请稍后再试\nDear customers, the content you want to get has not been enabled yet! Please try again later");
        }catch (RemoteException e){
            System.out.println("尊敬的客户，远程连接出现错误，请稍后再试试吧\nDear customer, remote connection error, please try again later");
        }
        try {
            byte[] result = file.read(length);
            return result;
        }catch (IOException e){

        }
        return null;/*待处理*/
    }

    public static boolean isInteger(String str) {
        Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$");
        return pattern.matcher(str).matches();
    }
}
