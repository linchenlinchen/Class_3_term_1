package itf;


public interface Id {
    String getIdStr();
}
