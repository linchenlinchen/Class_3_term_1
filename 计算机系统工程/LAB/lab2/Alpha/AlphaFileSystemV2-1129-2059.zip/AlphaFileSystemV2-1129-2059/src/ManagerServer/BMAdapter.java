package ManagerServer;

import itf.Block;
import itf.BlockManager;
import itf.Id;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface BMAdapter extends Remote {
    BlockManager getBlockManager() throws RemoteException;
    Block getBlock(Id id) throws RemoteException;
    byte[] read(Id id)throws RemoteException;
//    void write(Id id,byte[] data) throws RemoteException;
//    Block newEmptyBlock(int blockSize)throws RemoteException;
//    Block newBlock(byte[] b)throws RemoteException;
}
