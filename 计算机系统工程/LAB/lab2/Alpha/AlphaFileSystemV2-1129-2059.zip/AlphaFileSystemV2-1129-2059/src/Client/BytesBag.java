package Client;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/*ClassName BytesBag
 *Description
 *Author 2019/11/29
 *Date 2019/11/29 14:35
 *Version 1.0
 */
public class BytesBag extends UnicastRemoteObject implements Serializable {
    private byte[] data;
    protected BytesBag(byte[] data) throws RemoteException {
        super();
        this.data = data;
    }
    public byte[] getData(){return data;}
}
