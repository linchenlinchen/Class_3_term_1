package itf;

public interface Id {
    public String getIdStr();
}
