package software;

import id.BlockId;
import id.FileId;
import itf.*;

public class Main {
    final static int DUPLICATION_NUMBER = 2;
    final static int NUMOFBM = 10;
    final static int NUMOFFM = 10;
    public static void main(String[] args) throws Exception {
        // write your code here
        /*保留上一次执行的某操作后的整个系统的状态信息*/
//        java.io.File initialize = new java.io.File("initialize");
//        if(!initialize.exists()){
//            initialize.createNewFile();
//        }else {
//
//        }
        /*创建两个默认文件夹*/
        java.io.File file1 = new java.io.File("FileManagers");
        java.io.File file2 = new java.io.File("BlockManagers");
        FileManager[] fileManagers = new FileManager[NUMOFFM];
        BlockManager[] blockManagers = new BlockManager[NUMOFBM];
        if (!file1.exists()) {
            file1.mkdir();
        }
        if (!file2.exists()) {
            file2.mkdir();
        }
        /*创建一个数据集*/
        byte[] data = new byte[3000];
        for (int i = 0; i < 3000; i++) {
            data[i] = (((char) ((int) (Math.random() * 74 + 48))) + "").getBytes()[0];
        }

        /*初始化*/
        /*系统有十个fileManagers*/
        for (int i = 0; i < NUMOFFM; i++) {
            java.io.File file = new java.io.File("fileManagers/fm-" + i);
            if (!file.exists()) {
                file.mkdir();
            }
            fileManagers[i] = new FileManagerIml("fm-"+i);
        }
        /*系统有十个blockManagers*/
        for (int i = 0; i < NUMOFBM; i++) {
            java.io.File file = new java.io.File("blockManagers/bm-" + i);
            if (!file.exists()) {
                file.mkdir();
                blockManagers[i] = new BlockManagerIml("bm-"+i);
            }else {
                blockManagers[i] = new BlockManagerIml("bm-"+i);
                java.io.File[] fs = file.listFiles();
                for (int j = 0; j < fs.length; j++) {
                    String r = fs[j].getPath().replace("\\","/");
                    System.out.println(r);
                    String head = r.split("\\.")[0];
                    String tail = r.split("\\.")[1];
                    if(tail.equals("data")){
                        int s = FileUtil.getSize(fs[++j].getPath());/*++j是为了指向meta文件并且下一次循环可以直接找到下一个data文件*/
                        Id id = new BlockId(Long.parseLong(head.split("/")[(head.split("/")).length-1]));
                        Block block = new BlockIml(s,blockManagers[i],id);
                        ((BlockManagerIml)blockManagers[i]).blocks.add(block);
                    }
                }
            }
        }

        /**/
        Id fileId = new FileId("test1");
        File file = ((FileManagerIml) fileManagers[1]).newFile((FileId) fileId);
        ((FileImpl) file).write(data);
        file.move(0,File.MOVE_HEAD);
        byte[] result = file.read(3000);
        for (int i = 0; i < 3000; i++) {
            System.out.print((char)(result[i]));
        }
    }
}
