function [ad1,ad2,flag1,flag2]=flag12move(a,flag)
switch flag
case 3
   as=a;
   as(1,2)=as(1,3);as(1,3)=0;flag1=4;ad1=as;%����Ԫ�شӣ�1��2�������Ƶ���1��3��
   as=a;
   as(1,2)=as(2,2);as(2,2)=0;flag2=1;ad2=as;
   return;
case -1
   as=a;
   as(1,2)=as(1,3);as(1,3)=0;flag1=4;ad1=as;
   as=a;
   as(1,2)=as(1,1);as(1,1)=0;flag2=-3;ad2=as;
   return;
case -4
   as=a;
   as(1,2)=as(1,1);as(1,1)=0;flag1=-3;ad1=as;
   as=a;
   as(1,2)=as(2,2);as(2,2)=0;flag2=1;ad2=as;
   return;
end
