a=[2 8 3;1 0 4;7 6 5];b=[1 2 3;8 0 4;7 6 5];
flag=0;zero=[0 0 0;0 0 0;0 0 0];gop=0;gclose=0;g=0;
f=[0 0 0 0 0 0];h=[0 0 0 0 0 0];ad=cat(3,zero,zero,zero,zero,zero,zero);
flag=[0 0 0 0];flagu=[0 0 0 0 0 0];
admin=cat(3,zero,zero,zero,zero);flagmin=[0 0 0 0];flag5=0;
au=cat(3,zero,zero,zero,zero,zero,zero);
fop=0;fclos=0;fop2=0;  %fop��fclos�ֱ�Ϊopen��close���еĴ�������
flagopen=0;flagclose=0;
open=cat(3,a);close=cat(3,zero);s=1;t=0;
while flag5~=1
   flagopen1=0;fop1=0;open1=zero;t
   if t==2000
      stop;
   end
   %�ҳ����ۺ���ֵ��С�ľ��󲢽�������close
   [fopmin,index]=min(fop);
   flagclose(t+1)=flagopen(index);close(:,:,t+1)=open(:,:,index);
   fclos(t+1)=fop(index);gclose(t+1)=gop(index);gop(index)=0;
   if index<s
      for i=index:s-1
         flagopen(i)=flagopen(i+1);
         open(:,:,i)=open(:,:,i+1);
         fop(i)=fop(i+1);gop(i)=gop(i+1);
      end
   end
   flagopen(s)=0;open(:,:,s)=zero;fop(s)=0;gop(s)=0
   t=t+1;s=s-1;
   if isequal(close(:,:,t),b)==1
      disp('success');
      close(:,:,t)
      flag5=1;
      stop;
   end
   
          %�ҳ�Ԫ��0�ھ����е�λ��   
      for x=1:3
         for z=1:3
            if close(x,z,t)==0
               k=x;m=z;
            end
         end
      end
      ad=cat(3,zero,zero,zero,zero);flag=[0 0 0 0];
      if k==2&m==2&g==0
         [ad(:,:,1),ad(:,:,2),ad(:,:,3),ad(:,:,4),flag(1),flag(2),flag(3),flag(4)]=flag0(close(:,:,t)); 

             elseif k==1&m==1         %ִ��0Ԫ������λ�ö�Ӧ�ľ����ƶ�����       
                  [ad(:,:,1),flag(1)]=flag11move(close(:,:,t),flagclose(t));
              for n=2:4
                ad(:,:,n)=zero;flag(n)=0;
              end
             elseif k==1&m==3
                [ad(:,:,1),flag(1)]=flag13move(close(:,:,t),flagclose(t));
                  for n=2:4
                     ad(:,:,n)=zero;flag(n)=0;
                  end
               elseif k==3&m==1
                  [ad(:,:,1),flag(1)]=flag31move(close(:,:,t),flagclose(t));
                  for n=2:4
                     ad(:,:,n)=zero;flag(n)=0;
                  end
               elseif k==3&m==3
                  [ad(:,:,1),flag(1)]=flag33move(close(:,:,t),flagclose(t));
                    for n=2:4
                     ad(:,:,n)=zero;flag(n)=0;
                    end
               %��Ԫ����12 21 23 32ʱ���ƶ��󷵻ؾ�����2����   
               elseif k==1&m==2
                  [ad(:,:,1),ad(:,:,2),flag(1),flag(2)]=flag12move(close(:,:,t),flagclose(t));
                  ad(:,:,4)=zero;flag(4)=0; ad(:,:,3)=zero;flag(3)=0;
               elseif k==2&m==1
                  [ad(:,:,1),ad(:,:,2),flag(1),flag(2)]=flag21move(close(:,:,t),flagclose(t));
                  ad(:,:,4)=zero;flag(4)=0; ad(:,:,3)=zero;flag(3)=0;
               elseif k==2&m==3
                  [ad(:,:,1),ad(:,:,2),flag(1),flag(2)]=flag23move(close(:,:,t),flagclose(t));
                  ad(:,:,4)=zero;flag(4)=0; ad(:,:,3)=zero;flag(3)=0;
               elseif k==3&m==2
                  [ad(:,:,1),ad(:,:,2),flag(1),flag(2)]=flag32move(close(:,:,t),flagclose(t));
                  ad(:,:,4)=zero;flag(4)=0; ad(:,:,3)=zero;flag(3)=0;
               elseif k==2&m==2
                  [ad(:,:,1),ad(:,:,2),ad(:,:,3),flag(1),flag(2),flag(3)]=flag22move(close(:,:,t),flagclose(t));
                  ad(:,:,4)=zero;flag(4)=0;
               end
               g=gclose(t)+1;
               %�����ۺ���ֵΪ��С�ľ����ƶ���ľ���ŵ�open��flagopen��
              for i=1:4
                  if isequal(ad(:,:,i),zero)==0
                     h1=differentnum(ad(:,:,i));
                     fop(s+1)=h1+g;
                 open(:,:,s+1)=ad(:,:,i);flagopen(s+1)=flag(i);
                  gop(s+1)=g;
                 s=s+1;
                
                  end
              end
  end 
  
   
