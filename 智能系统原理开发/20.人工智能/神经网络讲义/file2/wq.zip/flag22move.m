function [ad1,ad2,ad3,flag1,flag2,flag3]=flag22move(a,flag)
switch flag
case 1
   as=a;
   as(2,2)=as(2,3);as(2,3)=0;flag1=4;ad1=as;
   as=a;
   as(2,2)=as(2,1);as(2,1)=0;flag2=-3;ad2=as;
   as=a;
   as(2,2)=as(3,2);as(3,2)=0;flag3=2;ad3=as;
   return;
case 3
   as=a;
   as(2,2)=as(1,2);as(1,2)=0;flag1=-1;ad1=as;
   as=a;
   as(2,2)=as(2,3);as(2,3)=0;flag2=4;ad2=as;
   as=a;
   as(2,2)=as(3,2);as(3,2)=0;flag3=2;ad3=as;
   return;
case -2
   as=a;
   as(2,2)=as(1,2);as(1,2)=0;flag1=-1;ad1=as;
   as=a;
   as(2,2)=as(2,1);as(2,1)=0;flag2=-3;ad2=as;
   as=a;
   as(2,2)=as(2,3);as(2,3)=0;flag3=4;ad3=as;
   return;
case -4
   as=a;
   as(2,2)=as(1,2);as(1,2)=0;flag1=-1;ad1=as;
   as=a;
   as(2,2)=as(2,1);as(2,1)=0;flag2=-3;ad2=as;
   as=a;
   as(2,2)=as(3,2);as(3,2)=0;flag3=2;ad3=as;
   return;

end

