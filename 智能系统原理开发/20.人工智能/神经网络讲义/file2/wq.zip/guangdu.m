a=[2 8 3;1 0 4;7 6 5];
zero=[0 0 0;0 0 0;0 0 0];
b=[1 2 3;8 0 4;7 6 5];
open=cat(3,zero);
close=cat(3,zero,zero);
open(:,:,1)=a;flag1=0;t=0;%�ñ��� t����ʾclose��������ľ���
s=1;                         %�ñ���s����ʾopen��������ľ���
cloflag=0;openflag=0;%ad=cat(3,zero,zero,zero,zero);
%flag=[0 0 0 0];
while flag1==0
      %t
      if isequal(open(:,:,1),zero)==1
      stop;
      end
      close(:,:,t+1)=open(:,:,s);
      open(:,:,s)=zero;
      t=t+1;s=s-1;
      if isequal(close(:,:,t),b)==1
         t
         disp('success');
         flag1=1;
         close(:,:,t)
      end
      if t==1500&flag1==0
         disp('fail'); 
         stop;
         flag1=1;
      end
      for x=1:3%�ҳ���Ԫ������λ�ã�
         for z=1:3
            if close(x,z,t)==zero
               k=x;m=z;
            end
         end
      end
      ad=cat(3,zero,zero,zero,zero);flag=[0 0 0 0];
      %ִ��0Ԫ������λ�ö�Ӧ�ľ����ƶ����� 
              if k==2&m==2&cloflag(length(cloflag))==0
              [ad(:,:,1),ad(:,:,2),ad(:,:,3),ad(:,:,4),flag(1),flag(2),flag(3),flag(4)]=flag0(close(:,:,t));
          %����Ԫ����11��13��31��33ʱ�����ؾ�����һ����
              elseif k==1&m==1               
                [ad(:,:,1),flag(1)]=flag11move(close(:,:,t),cloflag(t));
               for n=2:4
                  ad(:,:,n)=zero;flag(n)=0;
               end
              elseif k==1&m==3
                [ad(:,:,1),flag(1)]=flag13move(close(:,:,t),cloflag(t));
                  for n=2:4
                     ad(:,:,n)=zero;flag(n)=0;
                  end
               elseif k==3&m==1
                [ad(:,:,1),flag(1)]=flag31move(close(:,:,t),cloflag(t));
                  for n=2:4
                     ad(:,:,n)=zero;flag(n)=0;
                  end
               elseif k==3&m==3
                [ad(:,:,1),flag(1)]=flag33move(close(:,:,t),cloflag(t));
                  for n=2:4
                     ad(:,:,n)=zero;flag(n)=0;
                  end
               %��Ԫ����12 21 23 32ʱ���ƶ��󷵻ؾ�����2����   
               elseif k==1&m==2
                  [ad(:,:,1),ad(:,:,2),flag(1),flag(2)]=flag12move(close(:,:,t),cloflag(t));
                  ad(:,:,4)=zero;flag(4)=0; ad(:,:,3)=zero;flag(3)=0;
               elseif k==2&m==1
                  [ad(:,:,1),ad(:,:,2),flag(1),flag(2)]=flag21move(close(:,:,t),cloflag(t));
                  ad(:,:,4)=zero;flag(4)=0;
                  ad(:,:,3)=zero;flag(3)=0;
               elseif k==2&m==3
                  [ad(:,:,1),ad(:,:,2),flag(1),flag(2)]=flag23move(close(:,:,t),cloflag(t));
                  ad(:,:,4)=zero;flag(4)=0; ad(:,:,3)=zero;flag(3)=0;
               elseif k==3&m==2
                  [ad(:,:,1),ad(:,:,2),flag(1),flag(2)]=flag32move(close(:,:,t),cloflag(t));
                  ad(:,:,4)=zero;flag(4)=0; ad(:,:,3)=zero;flag(3)=0;
               elseif k==2&m==2
                  [ad(:,:,1),ad(:,:,2),ad(:,:,3),flag(1),flag(2),flag(3)]=flag22move(close(:,:,t),cloflag(t));
                  ad(:,:,4)=zero;flag(4)=0;
               end
               for c=1:4
                  if flag(c)~=0
                     cloflag(length(cloflag)+1)=flag(c);
                  end
               end
               %���ƶ���� ad��flag����open��cloflag��β��
               for i=1:4
                  if isequal(ad(:,:,i),zero)==0
             %��open�����ÿһ��Ԫ�ض������ƶ�һ��λ�ã�Ȼ��ad���η���open(:,:,1����
                     if s~=0
                     for j=s:-1:1
                        open(:,:,j+1)=open(:,:,j);
                     end
                     end
                     open(:,:,1)=ad(:,:,i);s=s+1;
                  end
               end
    end
         
               
      