function [ad,flag1]=flag33move(a,flag)
if flag==2
   a(3,3)=a(3,2);a(3,2)=0;flag1=-4;ad=a;
elseif flag==4
   a(3,3)=a(2,3);a(2,3)=0;flag1=-2;
   ad=a;
  
end; return;