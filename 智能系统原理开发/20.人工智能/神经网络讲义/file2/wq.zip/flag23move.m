function [ad1,ad2,flag1,flag2]=flag23move(a,flag)
switch flag
case 1
   as=a;
   as(2,3)=as(3,3);as(3,3)=0;flag1=2;ad1=as;
   as=a;
   as(2,3)=as(2,2);as(2,2)=0;flag2=-4;ad2=as;
   return;
case -2
   as=a;
   as(2,3)=as(1,3);as(1,3)=0;flag1=-1;ad1=as;
   as=a;
   as(2,3)=as(2,2);as(2,2)=0;flag2=-4;ad2=as;
   return;
case 4
   as=a;
   as(2,3)=as(1,3);as(1,3)=0;flag1=-1;ad1=as;
   as=a;
   as(2,3)=as(3,3);as(3,3)=0;flag2=2;ad2=as;
   return;
end
