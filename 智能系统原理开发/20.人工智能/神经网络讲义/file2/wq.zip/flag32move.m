function [ad1,ad2,flag1,flag2]=flag32move(a,flag)
switch flag
case 3
   as=a;
   as(3,2)=as(3,3);as(3,3)=0;flag1=4;ad1=as;%����Ԫ�شӣ�1��2�������Ƶ���1��3��
   as=a;
   as(3,2)=as(2,2);as(2,2)=0;flag2=-2;ad2=as;
   return;
case 2
   as=a;
   as(3,2)=as(3,3);as(3,3)=0;flag1=4;ad1=as;
   as=a;
   as(3,2)=as(3,1);as(3,1)=0;flag2=-3;ad2=as;
   return;
case -4
   as=a;
   as(3,2)=as(3,1);as(3,1)=0;flag1=-3;ad1=as;
   as=a;
   as(3,2)=as(2,2);as(2,2)=0;flag2=-2;ad2=as;
   return;
end
