function [ad,flag1]=flag31move(a,flag)
if flag==2
   a(3,1)=a(3,2);a(3,2)=0;flag1=3;ad=a;
elseif flag==-3
   a(3,1)=a(2,1);a(2,1)=0;flag1=-2;
   ad=a;
  
end; return;