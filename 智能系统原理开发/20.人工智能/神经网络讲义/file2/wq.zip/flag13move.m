function [ad,flag1]=flag13move(a,flag)
if flag==-1
   a(1,3)=a(1,2);a(1,2)=0;flag1=-4;ad=a;
elseif flag==4
   a(1,3)=a(2,3);a(2,3)=0;flag1=1;
   ad=a;
  
end; return;