function [ad,flag1]=flag11move(a,flag)
if flag==-1
   a(1,1)=a(1,2);a(1,2)=0;flag1=3;ad=a;
elseif flag==-3
   a(1,1)=a(2,1);a(2,1)=0;flag1=1
   ad=a;
  
end; return;