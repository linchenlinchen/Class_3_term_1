function [ad1,ad2,ad3,ad4,flag1,flag2,flag3,flag4]=flag0(a)
as=a;as(2,2)=as(2,1);as(2,1)=0;
flag1=-3;ad1=as;

as=a;as(2,2)=as(1,2);as(1,2)=0;
flag2=-1;ad2=as;

as=a;as(2,2)=as(2,3);as(2,3)=0;
flag3=4;ad3=as;

as=a;as(2,2)=as(3,2);as(3,2)=0;
flag4=2;ad4=as;
return;