function [ad1,ad2,flag1,flag2]=flag21move(a,flag)
switch flag
case 1
   as=a;
   as(2,1)=as(3,1);as(3,1)=0;flag1=2;ad1=as;%����Ԫ�شӣ�1��2�������Ƶ���1��3��
   as=a;
   as(2,1)=as(2,2);as(2,2)=0;flag2=3;ad2=as;
   return;
case -2
   as=a;
   as(2,1)=as(1,1);as(1,1)=0;flag1=-1;ad1=as;
   as=a;
   as(2,1)=as(2,2);as(2,2)=0;flag2=3;ad2=as;
   return;
case -3
   as=a;
   as(2,1)=as(1,1);as(1,1)=0;flag1=-1;ad1=as;
   as=a;
   as(2,1)=as(3,1);as(3,1)=0;flag2=2;ad2=as;
   return;
end
